#!/bin/bash

# Run tests, and sum score
pytest -rPf
python3 sumresult.py
