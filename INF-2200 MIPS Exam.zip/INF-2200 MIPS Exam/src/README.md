# MIPS TESTS
The mips tests are conducted on short specific instructions, pin pointing as narrow as possible test cases

## Test layout
Each test is testing as few instructions as possible. The layout for each file is:
**Test name -> Result register/address -> Expected value -> Trap or no trap expected